// UserCard.js
import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';

function UserCard({ userData }) {
  return (
    <Card className="user-card">
      <CardContent>
        <Typography variant="h5" gutterBottom>
          User Information
        </Typography>
        <Typography>Name: {userData.name}</Typography>
        <Typography>Date of Birth: {userData.dob}</Typography>
        <Typography>Email: {userData.email}</Typography>
        <Typography>Contact Number: {userData.contact}</Typography>
        <Typography>About: {userData.about}</Typography>
      </CardContent>
    </Card>
  );
}

export default UserCard;
