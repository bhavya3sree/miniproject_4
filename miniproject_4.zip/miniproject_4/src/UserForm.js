// UserForm.js
import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

function UserForm({ onFormSubmit }) {
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    email: '',
    contact: '',
    about: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const isAlphabetic = (input) => /^[A-Za-z]+$/.test(input);
  const isNumeric = (input) => /^\d+$/.test(input);

  const handleSubmit = () => {
    
    if (
      formData.name &&
      isAlphabetic(formData.name) &&
      formData.dob &&
      new Date(formData.dob) <= new Date() && 
      formData.email &&
      /\S+@\S+\.\S+/.test(formData.email) && 
      formData.contact &&
      isNumeric(formData.contact) &&
      formData.contact.length === 10 &&
      formData.about
    ) {
      onFormSubmit(formData);
    } else {
      alert('Validation failed. Please check your inputs.');
    }
  };

  return (
    <div className="user-form">
      <TextField
        label="Name"
        name="name"
        value={formData.name}
        onChange={handleChange}
      />
      <TextField
        label="Date of Birth"
        type="date"
        name="dob"
        value={formData.dob}
        onChange={handleChange}
      />
      <TextField
        label="Email Id"
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
      />
      <TextField
        label="Contact Number"
        name="contact"
        value={formData.contact}
        onChange={handleChange}
      />
      <TextField
        label="Tell me about yourself"
        multiline
        rows={4}
        name="about"
        value={formData.about}
        onChange={handleChange}
      />
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Submit
      </Button>
    </div>
  );
}

export default UserForm;
