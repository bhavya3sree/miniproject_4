// App.js
import React, { useState } from 'react';
import Navbar from './Navbar';
import UserForm from './UserForm';
import UserCard from './UserCard';
import './App.css';

function App() {
  const [userData, setUserData] = useState(null);

  const handleFormSubmit = (data) => {
    setUserData(data);
  };

  return (
    <div className="app">
      <Navbar />
      <UserForm onFormSubmit={handleFormSubmit} />
      {userData && <UserCard userData={userData} />}
    </div>
  );
}

export default App;
